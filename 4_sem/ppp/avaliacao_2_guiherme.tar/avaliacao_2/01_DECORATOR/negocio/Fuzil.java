package negocio;

public class Fuzil extends Arma {

    public Fuzil(){
        this.cost = 199;
        this.description = "Fuzil AR15";
    }

   
    
}
