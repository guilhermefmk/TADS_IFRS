package negocio;

public abstract class Arma {
    protected String description;
    protected double cost;

    
    public String getDescription() {
        return this.description;
        
    }

    public double cost() {
        return this.cost;
    }
    
}
