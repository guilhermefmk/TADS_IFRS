package negocio;

public class Pistola extends Arma {

    public Pistola(){
        this.cost = 199;
        this.description = "Pistola Glock";
    }

   
    
}
