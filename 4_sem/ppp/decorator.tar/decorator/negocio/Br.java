package negocio;

public class Br extends HtmlDecorator {

    public Br(Html html) {
        super(html, "<br>");
    }
}
