package modelo;

public interface Model {
    void manobrarCarro(Carro carro);
}
