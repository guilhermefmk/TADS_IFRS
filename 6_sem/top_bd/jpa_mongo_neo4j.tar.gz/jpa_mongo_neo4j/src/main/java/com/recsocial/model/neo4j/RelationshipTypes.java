package com.recsocial.model.neo4j;

public class RelationshipTypes {
    public static final String SEGUE = "SEGUE";
    public static final String CURTIU = "CURTIU";
    public static final String COMENTOU = "COMENTOU";
    public static final String VISITOU_PERFIL = "VISITOU_PERFIL";
}